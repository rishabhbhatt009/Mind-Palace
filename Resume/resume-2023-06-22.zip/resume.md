<!-------------------------------------------------------------------------------------------
- Things to improve 
    - adding intro and shifting skills for each experience 
    - adding content 
    - Pinecone
--------------------------------------------------------------------------------------------->


<!------------------------------------------------------------------------------------------->

<!-- Meta Data -->
@REDACTED=false

@NAME=Rishabh Bhatt||Hidden
@EMAIL=rishabhbhatt.app@gmail.com||fake@email.com
@PHONE=470-529-8821||(000)-000-0000
@LOCATION=State College, PA||City, State
@LINKEDIN=linkedin.com/in/rishabh-bhatt||linkedin.com
@GITHUB=github.com/rishabhbhatt009||github.com
@PORTFOLIO=rishabhbhatt009.github.io ||portfolio.io

<!-- Links -->
@ALEXA_TASKBOT_LINK=https://www.amazon.science/alexa-prize/taskbot-challenge/ten-university-teams-selected-for-alexa-prize-taskbot-challenge-2

@KNOWLEDGE_GROUNDED_CHATBOT=https://github.com/rishabhbhatt009/Knowledge-Grounded-ChatBot
@GESTURE_RECOGNITION=https://github.com/rishabhbhatt009/Gesture-Recognition
@GAME_BOT=https://github.com/rishabhbhatt009/Game-Bot


<!------------------------------------------------------------------------------------------->

# {NAME}
{LOCATION} **|** {EMAIL} 
<span class="horizontal-spacer"> </span> 
[{LINKEDIN}](https://{LINKEDIN}) **|** [{PORTFOLIO}](https://{PORTFOLIO})  

<div className="vertical-spacer"></div>

<!------------------------------------------------------------------------------------------->

## Skills

<span class="skill-category">Back-End</span> 
<span class="skill-spacer">|</span> 
Python, Java, C++, Django, SQL, NoSQL, Microservices, RESTful API Development

<span class="skill-category">Data-Science</span> 
<span class="skill-spacer">|</span> 
Scikit-Learn, PyTorch, Apache Spark, Hugging-Face, TensorFlow, SpaCy, OpenCV, Pandas, Dask, Tableau

<span class="skill-category">Developer-Tools</span> 
<span class="skill-spacer">|</span> 
Git, Docker, Kubernetes, Linux, GitHub Actions, Jira 

<div className="vertical-spacer"></div>


<!------------------------------------------------------------------------------------------->

## Experience

### Backend Software Developer | EvoquerBOT <span class="horizontal-spacer"> </span> Jan 2023 - Present
Skills : PyTorch | Alexa Skills Kit APIs | AWS | Docker | DynamoDB | Neo4j | Microservices | Machine Learning

- Build and deploy at scale a multi-modal virtual assistant, to compete against 10 teams selected globally for the [Alexa Prize TaskBot Challenge]({ALEXA_TASKBOT_LINK}), by integrating neural functionalities into an alexa skill using **ASK APIs**. Try it! Say *"Alexa, lets work together me"*
- Implemented a scalable and efficient neural response generator by consolidating responses from multiple neural functionalities hosted as isolated microservices containerized with Docker, enabling rapid deployment and scalable service delivery
- Enabled 30% faster and 60% more accurate information retrieval by designing a persistent knowledge database with a custom API to perform **CRUD** operations and query data from natural language input
- Proactively identified bugs with backend services and API, and communicated the issues and findings to senior engineers at Amazon 

<!-- 
- Developed an AI-powered Alexa-Skill, deployed on AWS using ASK APIs and Python for the
[Amazon Task-Bot Challenge 2023]({ALEXA_TASKBOT_LINK})
- Implemented a scalable and efficient neural response generator by consolidating response from multi-modal neural functionalities hosted as isolated microservices containerized with Docker, enabling rapid deployment and scalable service delivery
- Designed and maintained a persistent knowledge database by using scrapped text stored in a Neo4j graph database, enabling version-control and efficient querying via a custom API, increasing data accuracy by 30% and 5 times faster retrieval
- Proactively identified bugs with backend services and API and communicated the issues to senior engineers at Amazon  
-->

<!--  --> <div className="vertical-spacer"></div>

### Decision Analytics Associate | ZS Associates <span class="horizontal-spacer"> </span> Sept 2019 - Apr 2021
Skills : Python | PostgreSQL | Scikit-Learn | Apache Spark | AWS | Pandas | Matplotlib

- Accelerated revenue growth for healthcare clients by 20% through digital transformation, by developing cloud-based data (**ELT**) pipelines to integrate data from numerous sources into **data warehouses** and optimizing analytical workflows with Apache Spark

- Helped clients identify KPIs and improve sales by over 15% QoQ, by analyzing anonymized longitudinal data (APLD) for millions of patients using **Marketing Mix models** and optimizing the sales force through geo-spatial alignment

- Increased client reach by 40% by applying unsupervised learning algorithms like **K-Means** to cluster over 500k customers into segments and analyzing effectiveness of marketing strategies using **A/B Testing** 


<!-- - Enabled digital transformation for healthcare clients by developing cloud-based ELT pipelines, integrating data from multiple sources into a unified data warehouse. Optimized analytical workflows with Apache Spark, resulting in streamlined data processing and enhanced data-driven decision-making.
- Leveraged Python to develop & deploy statistical models analyzing anonymized longitudinal patient data (APLD) for millions of patients in the Oncology Market ($265B). Identified market trends, predicted product growth potential, and optimized sales force and marketing strategies, leading to over 10% increase in revenue and significant cost savings.
- Applied unsupervised learning algorithms to cluster over 500k customers, revealing market segments and behavior patterns.Improved customer experience and increased client reach through targeted messaging, driving business growth. -->

<!--  --> <div className="vertical-spacer"></div>

### Software Development Intern | Velankani Electronics <span class="horizontal-spacer"></span> May 2018 - Jul 2018
Skills : C++, OpenCV, Qt, Convoluted Neural Networks, GUI

- Developed a license plate recognition system using convolutional neural networks (CNNs) and integrated it into a user friendly surveillance graphical user interface using QT.

<!--  --> <div className="vertical-spacer"></div>

<!------------------------------------------------------------------------------------------->
## Education

**Pennsylvania State University** - Master's of Science in Computer Science, **GPA 3.7**
<span class="horizontal-spacer"></span>2021-2023

**Vellore Institute of Technology** - Bachelor's of Technology in Computer Science spl. in Bioinformatics, **GPA 8.23**
<span class="horizontal-spacer"></span>2015-2019   

<div className="vertical-spacer-small"></div>

**Certifications** - 
[IBM DS Professional Certification](https://www.coursera.org/account/accomplishments/professional-cert/7FBTEXGLEJUA), 
[AWS Machine Learning](https://www.coursera.org/account/accomplishments/verify/2Y47DNAPDC29), 
[ML Stanford University](https://www.coursera.org/account/accomplishments/verify/GEY2QQZP6AH3), 
[Emotional Intelligence NPTEL](https://nptel.ac.in/noc/social_cert/noc19-hs11/NPTEL19HS11S11950186191017174.jpg) 

<div className="vertical-spacer"></div>

<!------------------------------------------------------------------------------------------->

## Projects 

<!-- **Knowledge Grounded Question Answering** - ([GitHub]({KNOWLEDGE_GROUNDED_CHATBOT}))
<span class="horizontal-spacer"> </span> Python | Pinecone | Hugging-Face | PyTorch

- Developed a chatbot using hugging faces 
- Document  -->

**Gesture Recognition via skeleton based Deep Neural Network** <span class="horizontal-spacer"> </span> 
*Python | Tensorflow | OpenCV | MediaPipe Framework* 
<!-- Details -->
- Developed a software which convert gestures to natural language using a Long Short-Term Memory (LSTM) network 
- Used Google's MediaPipe framework to extract skeletal graph data from over **21k videos (~5Gbs)** to train the model 

**Atari Game Bots using Reinforcement Learning (RL)**
<span class="horizontal-spacer"> </span> 
*PyTorch | OpenAI gym | Matplotlib*
- Trained AI-bots to play games and solve puzzles using Deep-Q-Learning (DQN) & Proximal-Policy-Optimization (PPO) algorithms 
- Conducted performance analysis by running multiple simulations in controlled environments to evaluate bot's efficiency.

<!-- **3D Skeleton Reconstruction for Augmented Reality**
<span class="horizontal-spacer"> </span> OpenCV | Python | Numpy | Matplotlib 
- Projected joint locations from real world to pixel coordinates & used these 2D estimations to reconstruct 3D human skeleton across ~70,000 frames of joint data using binocular vision -->

**Analyzing Social Sentiments using scraped tweets**
<span class="horizontal-spacer"> </span> 
*Python | Scikit-Learn | tweepy | SpaCy | NLTK*

- Used twitter-API to scrape tweets and generate a dataset of over **1.2 million tweets** to perform sentiment analysis in Python
- Built a data dashboard with interactive visualization to analyze public sentiment before and after “Lok Sabha Elections in India”

<!------------------------------------------------------------------------------------------->

## Publications
- **"Indian Sign Language Recognition System using Adaptable Segmentation & ML"**- Rishabh Bhatt & Dr. Vishal Bharti <br>
Published: GRENZE International Journal of Engineering & Technology, 2020 Vol-6 Issue-1 (ISSN: 2395-5295), pages 27-36
- **“Cyberbullying & the need to reform cyber laws in India: The Venus Fly Trap Analogy”**- Rishabh Bhatt <br>
Published: OIIRJ Volume-09, July 2019 Special Issue (ISSN: 2249-9598), pages 289-297

<!------------------------------------------------------------------------------------